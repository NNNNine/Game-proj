package entity;

public class PlayerBall extends Ball{
    
}
