package entity;

public class EnemyBall extends Ball{
    
}
