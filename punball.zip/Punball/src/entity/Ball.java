package entity;

public abstract class Ball {
    public int ball_ammo;

    public Ball() {
        
    }

}
