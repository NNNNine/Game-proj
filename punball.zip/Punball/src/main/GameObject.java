package main;

public abstract class GameObject {
    
}
